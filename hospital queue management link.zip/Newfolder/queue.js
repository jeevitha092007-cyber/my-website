function getPriority(patient) {
    if (patient.type === 'Emergency') return 1;
    if (patient.age >= 60) return 2;
    if (patient.age <= 12) return 3;
    return 4;
}

function getPriorityLabel(patient) {
    if (patient.type === 'Emergency')
        return '<span class="priority-badge p-emergency">Emergency</span>';
    if (patient.age >= 60)
        return '<span class="priority-badge p-senior">Senior</span>';
    if (patient.age <= 12)
        return '<span class="priority-badge p-child">Child</span>';
    return '<span class="priority-badge p-normal">Normal</span>';
}

function loadQueue() {
    let queue = JSON.parse(localStorage.getItem('queue')) || [];
    const tbody = document.querySelector('#queueTable tbody');
    const noPatientsMsg = document.getElementById('noPatientsMsg');

    tbody.innerHTML = '';

    if (queue.length === 0) {
        noPatientsMsg.style.display = 'block';
        return;
    } else {
        noPatientsMsg.style.display = 'none';
    }

    queue.sort((a, b) => {
        const pa = getPriority(a);
        const pb = getPriority(b);

        if (pa !== pb) return pa - pb;
        return a.token - b.token; // FIFO
    });

    queue.forEach((p, index) => {
        const tr = document.createElement('tr');
        if (p.type === 'Emergency') tr.classList.add('emergency');

        tr.innerHTML = `
            <td>${index + 1}</td>
            <td>${p.token}</td>
            <td>${p.name}</td>
            <td>${p.age}</td>
            <td>${p.department}</td>
            <td>${p.type}</td>
            <td>${getPriorityLabel(p)}</td>
        `;

        tbody.appendChild(tr);
    });
}

window.onload = loadQueue;
