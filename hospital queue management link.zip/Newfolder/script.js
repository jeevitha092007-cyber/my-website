// Get queue from localStorage or initialize
let queue = JSON.parse(localStorage.getItem("queue")) || [];
let tokenNumber = localStorage.getItem("tokenNumber")
    ? parseInt(localStorage.getItem("tokenNumber"))
    : 0;

// Function to generate token (for the last registered patient)
function generateToken() {
    if(queue.length === 0) {
        alert("No patients registered yet! Please register first.");
        return;
    }

    // Get last patient
    const patient = queue[queue.length - 1];
    tokenNumber = patient.token;

    // Display the last token in tokenBox
    document.getElementById("tokenValue").innerHTML = `
        <strong>Token No:</strong> ${patient.token} <br>
        <strong>Patient Name:</strong> ${patient.name} <br>
        <strong>Age:</strong> ${patient.age} <br>
        <strong>Department:</strong> ${patient.department} <br>
        <strong>Patient Type:</strong> ${patient.type}
    `;

    // Update queue display
    updateQueueList();
}

// Function to show the full queue
function updateQueueList() {
    const ul = document.getElementById("queueList");

    if(queue.length === 0){
        ul.innerHTML = "<li>No tokens yet.</li>";
        return;
    }

    // Build HTML for the queue
    let html = "";
    queue.forEach(patient => {
        html += `<li>Token ${patient.token} - ${patient.name} (${patient.department}, ${patient.type})</li>`;
    });

    ul.innerHTML = html;
}

// Update queue display on page load
updateQueueList();
