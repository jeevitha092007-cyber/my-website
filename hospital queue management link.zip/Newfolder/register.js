document.getElementById('registrationForm').addEventListener('submit', function(e) {
    e.preventDefault();

    // Get form values
    const name = document.getElementById('name').value.trim();
    const age = document.getElementById('age').value.trim();
    const department = document.getElementById('department').value;
    const type = document.getElementById('type').value;

    if (!name || !age || !department || !type) return alert('Please fill all fields');

    // Load queue from localStorage
    let queue = JSON.parse(localStorage.getItem('queue')) || [];

    // Generate token
    let lastToken = queue.length ? queue[queue.length - 1].token : 0;
    const token = Number(lastToken) + 1;

    // Create patient object
    const patient = { token, name, age, department, type, priority: type === 'Emergency' ? 1 : 2 };

    // Add to queue
    queue.push(patient);
    localStorage.setItem('queue', JSON.stringify(queue));
    localStorage.setItem('lastToken', token);

    // Redirect to token page
    window.location.href = 'token.html';
});
