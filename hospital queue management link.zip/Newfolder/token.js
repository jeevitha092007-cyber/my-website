let queue = JSON.parse(localStorage.getItem("queue")) || [];
const container = document.getElementById("tokenText");

/* 🔊 Beep sound */
const beep = new Audio("https://assets.mixkit.co/sfx/preview/mixkit-software-interface-start-2574.mp3");

/* No patients */
if (queue.length === 0) {
    container.innerHTML = `
        <div class="empty">
            <h3>No patients registered yet</h3>
            <p>Please generate a token first</p>
        </div>
    `;
} else {

    /* ⚡ Priority sorting */
    queue.sort((a, b) => {
        if (a.type === "Emergency") return -1;
        if (b.type === "Emergency") return 1;
        if (a.type === "Senior Citizen") return -1;
        if (b.type === "Senior Citizen") return 1;
        return a.token - b.token;
    });

    let html = `<h3>Queue List</h3><div class="queue-dashboard">`;

    queue.forEach(p => {
        let badge = "";
        let cardClass = "";

        if (p.type === "Emergency") {
            badge = "🚨 Emergency";
            cardClass = "emergency";
        } else if (p.type === "Senior Citizen") {
            badge = "👴 Senior";
            cardClass = "senior";
        } else {
            badge = "Regular";
        }

        html += `
            <div class="queue-card ${cardClass}">
                <h4>Token ${p.token}</h4>
                <p><strong>${p.name}</strong></p>
                <p>${p.department}</p>
                <span class="badge">${badge}</span>
            </div>
        `;
    });

    html += `</div>`;
    container.innerHTML = html;

    /* 🔔 Play beep when queue updates */
    beep.play().catch(() => {});
}
